package ts.hn.tstest;

public class TsConst {
    public static final int TS_REGISTER = 1;
    public static final int TS_UNREGISTER = 2;
    
    public static final int TS_PLAY_POSITION = 3;
    public static final int TS_PAUSE = 4;
    public static final int TS_STOP = 5;
    public static final int TS_RESUME = 6;
    
    public static final int TS_NEXT = 6;
}
