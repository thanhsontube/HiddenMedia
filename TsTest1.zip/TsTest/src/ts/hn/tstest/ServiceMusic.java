package ts.hn.tstest;

import java.io.IOException;
import java.util.Stack;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

public class ServiceMusic extends Service {

    private static final String TAG = "ServiceMusic";
    private Messenger messenger;
    private Stack<Messenger> stackMessenger;
    private FilterLog log = new FilterLog(TAG);

    private MediaPlayer player;
    private ResouceManager resource;

    @SuppressLint("HandlerLeak")
    private class IncommingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case TsConst.TS_REGISTER:
                stackMessenger.add(msg.replyTo);
                break;
            case TsConst.TS_UNREGISTER:
                stackMessenger.remove(msg.replyTo);
                break;

            case TsConst.TS_PLAY_POSITION:
                int index = msg.arg1;
                playSong(index);
                break;
            case TsConst.TS_PAUSE:
                pauseSong();
                break;
            case TsConst.TS_STOP:
                stopSong();
                break;
            case TsConst.TS_RESUME:
                resumeSong();
                break;

            default:
                break;
            }
            log.d("log>>>" + "stackMessenger :" + stackMessenger.size());
            // super.handleMessage(msg);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        messenger = new Messenger(new IncommingHandler());
        stackMessenger = new Stack<Messenger>();

        player = new MediaPlayer();
        resource = ResouceManager.getInstance();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return messenger.getBinder();
    }

    public static Intent getIntentService(Context context) {
        Intent intent = new Intent();
        intent.setClass(context, ServiceMusic.class);
        return intent;
    }

    private void playSong(final int index) {
        try {
            log.d("log>>>" + "path:" + resource.getListMusic().get(index).path);
            player.reset();
            player.setDataSource(resource.getListMusic().get(index).path);
            player.setOnErrorListener(new OnErrorListener() {

                @Override
                public boolean onError(MediaPlayer arg0, int arg1, int arg2) {
                    log.e("log>>>" + "onError");
                    playSong(index + 1);
                    sendMsgToClient(index + 1);
                    return false;
                }
            });
            player.setOnCompletionListener(new OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer arg0) {
                    playSong(index + 1);
                    sendMsgToClient(index + 1);
                }
            });
            player.prepare();
            player.start();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private void pauseSong() {
        if (player.isPlaying()) {
            player.pause();
        }
    }

    private void resumeSong() {
        player.start();
    }

    private void stopSong() {
        if (player.isPlaying()) {
            player.stop();
        }
    }

    private void sendMsgToClient(int index) {
        if (index == resource.getListMusic().size() - 1) {
            return;
        }
        for (Messenger messenger : stackMessenger) {
            Message msg = Message.obtain(null, TsConst.TS_NEXT, index, 0);
            try {
                messenger.send(msg);
            } catch (RemoteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

}
