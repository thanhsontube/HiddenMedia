package ts.hn.tstest.a.messenger;

public class VideoMessenger {

}
